﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 学生管理系统
{
    public class TagObject
    {
        public int EditId { get; set; }

        public Action ReLoad { get; set; }

    }
}
